# dockertomcat

This Dockerfile is a Sample Dockerfile to create Tomcat of any version by Just Replacing a Single Varibale during Docker Build. This is something which has been introduced by Docker with ARGS Instruction!
